#include <main_state.h>
#include <glad/glad.h>
#include <math.h>


#include <rafgl.h>

#include <game_constants.h>


rafgl_texture_t skybox_tex, night_tex;

rafgl_framebuffer_multitarget_t fbo1, fbo_grayscaled, fbo_blur_stage1, fbo_blurred, fbo_bloom;
rafgl_meshPUN_t skybox_mesh, bunny_mesh, sc_mesh, mnt_mesh;

GLuint skybox_shader, skybox_uni_P, skybox_uni_V;
GLuint object_shader, object_uni_M, object_uni_VP, object_uni_object_colour, object_uni_light_colour, object_uni_light_direction, object_uni_ambient, object_uni_camera_position;

vec3_t object_colour = vec3m(0.8f, 0.40f, 0.0f);
vec3_t light_colour = RAFGL_WHITE;
vec3_t light_direction = vec3m(-0.924f, -0.184f, -0.335f);
vec3_t ambient = RAFGL_GRAYX(0.2f);

int swidth, sheight;

#define BLUR_DOWNSCALE_POWER 3
int blur_downscale_factor = 1 << BLUR_DOWNSCALE_POWER;

GLuint quad_vao;

GLfloat quad_vertices[] =
{
     1.0f,  1.0f,  0.0f, 1.0f, 1.0f,
    -1.0f,  1.0f,  0.0f, 0.0f, 1.0f,
    -1.0f, -1.0f,  0.0f, 0.0f, 0.0f,

     1.0f,  1.0f,  0.0f, 1.0f, 1.0f,
    -1.0f, -1.0f,  0.0f, 0.0f, 0.0f,
     1.0f, -1.0f,  0.0f, 1.0f, 0.0f,
};

GLuint grayscale_shader, gauss_horizontal_shader, gauss_vertical_shader, bloom_shader;
GLuint uni_h_vertical, uni_w_horizontal;

GLuint uni_tex_slot, uni_highlight_slot, uni_lod;
GLuint sc_uni_M, sc_uni_VP, sc_shader;

void main_state_init(GLFWwindow *window, void *args, int width, int height)
{

    swidth = width;
    sheight = height;
    GLuint quad_vbo;

    glGenVertexArrays(1, &quad_vao);
    glGenBuffers(1, &quad_vbo);

    glBindVertexArray(quad_vao);
    glBindBuffer(GL_ARRAY_BUFFER, quad_vbo);

    glBufferData(GL_ARRAY_BUFFER, sizeof(quad_vertices), quad_vertices, GL_STATIC_DRAW);

    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));

    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);

    fbo1 = rafgl_framebuffer_multitarget_create(width, height, 3);

    glBindTexture(GL_TEXTURE_2D, fbo1.tex_ids[1]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glBindTexture(GL_TEXTURE_2D, 0);


    fbo_grayscaled = rafgl_framebuffer_multitarget_create(width, height, 1);
    fbo_blur_stage1 = rafgl_framebuffer_multitarget_create(width / blur_downscale_factor, height / blur_downscale_factor, 1);
    fbo_blurred = rafgl_framebuffer_multitarget_create(width / blur_downscale_factor, height / blur_downscale_factor, 1);
    fbo_bloom = rafgl_framebuffer_multitarget_create(width, height, 1);




    grayscale_shader = rafgl_program_create_from_name("pp_grayscale");


    bloom_shader = rafgl_program_create_from_name("pp_bloom");

    uni_tex_slot = glGetUniformLocation(bloom_shader, "tex");
    uni_highlight_slot = glGetUniformLocation(bloom_shader, "highlight");

    gauss_horizontal_shader = rafgl_program_create_from_name("pp_gauss_horizontal");
    gauss_vertical_shader = rafgl_program_create_from_name("pp_gauss_vertical");

    uni_h_vertical = glGetUniformLocation(gauss_vertical_shader, "target_height");
    uni_w_horizontal = glGetUniformLocation(gauss_horizontal_shader, "target_width");

    uni_lod = glGetUniformLocation(gauss_horizontal_shader, "lod");

    rafgl_texture_init(&skybox_tex);
    rafgl_texture_init(&night_tex);
    rafgl_texture_load_cubemap_named(&night_tex, "night", "png");
    rafgl_texture_load_cubemap_named(&skybox_tex, "above_the_sea", "jpg");
    skybox_shader = rafgl_program_create_from_name("skybox_shader");

    skybox_uni_P = glGetUniformLocation(skybox_shader, "uni_P");
    skybox_uni_V = glGetUniformLocation(skybox_shader, "uni_V");

    object_shader = rafgl_program_create_from_name("lambert_shader");



    object_uni_M = glGetUniformLocation(object_shader, "uni_M");
    object_uni_VP = glGetUniformLocation(object_shader, "uni_VP");

    object_uni_object_colour = glGetUniformLocation(object_shader, "uni_object_colour");
    object_uni_light_colour = glGetUniformLocation(object_shader, "uni_light_colour");
    object_uni_light_direction = glGetUniformLocation(object_shader, "uni_light_direction");
    object_uni_ambient = glGetUniformLocation(object_shader, "uni_ambient");
    object_uni_camera_position = glGetUniformLocation(object_shader, "uni_camera_position");

    sc_shader = rafgl_program_create_from_name("sc_shader");
    sc_uni_M = glGetUniformLocation(sc_shader, "uni_M");
    sc_uni_VP = glGetUniformLocation(sc_shader, "uni_VP");


    rafgl_meshPUN_init(&skybox_mesh);
    rafgl_meshPUN_load_cube(&skybox_mesh, 1.0f);

    rafgl_meshPUN_init(&bunny_mesh);
    rafgl_meshPUN_load_from_OBJ(&bunny_mesh, "res/models/bunny.obj");

    rafgl_meshPUN_init(&sc_mesh);
    rafgl_meshPUN_load_from_OBJ(&sc_mesh, "res/models/Monitor-Screen.obj");

    rafgl_meshPUN_init(&mnt_mesh);
    rafgl_meshPUN_load_from_OBJ(&mnt_mesh, "res/models/Monitor-Frame.obj");


    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glEnable(GL_DEPTH_TEST);

}


mat4_t model1, view1, projection1, view_projection1;
mat4_t model2, view2, projection2, view_projection2;

/* field of view */
float fov = 75.0f;

vec3_t camera_position[2] = {vec3m(0.0f, 1.0f, 6.5f), vec3m(0.04f, 2.44f, 1.34f)};
vec3_t camera_target[2] = {vec3m(0.0f, 0.0f, 0.0f), vec3m(0.0f, 0.0f, 0.0f)};
vec3_t camera_up[2] = {vec3m(0.0f, 1.0f, 0.0f), vec3m(0.0f, 1.0f, 0.0f)};
vec3_t aim_dir[2] = {vec3m(0.0f, 0.0f, -1.0f), vec3m(0.0f, 0.0f, -1.0f)};

int selected_c = 0;

float camera_angle[2] = {-M_PIf * 0.5f, -M_PIf * 0.5f};
float angle_speed = 0.2f * M_PIf;
float move_speed = 2.4f;

float hoffset[2] = {0, 0};

int rotate = 0;
float model_angle = 0.0f;

void v3show(vec3_t v)
{
    printf("(%.2f %.2f %.2f)\n", v.x, v.y, v.z);
}

float time = 0.0f;
int reshow_cursor_flag = 0;
int last_lmb = 0;


int selected_mesh = 3;
float sensitivity = 1.0f;

int selected_shader = 0;

float visibility_factor = -2.0f;
float turn = 1.0f;

int selected_effect = 0;

void main_state_update(GLFWwindow *window, float delta_time, rafgl_game_data_t *game_data, void *args)
{
    visibility_factor += delta_time * turn;
    if(visibility_factor > 12.0f) turn = -1;
    if(visibility_factor < -5.0f) turn = 1;

    time += delta_time;
    model_angle += delta_time * rotate;

    if(game_data->keys_down[RAFGL_KEY_LEFT_SHIFT] && game_data->keys_pressed[RAFGL_KEY_C])
    {
        selected_c = !selected_c;
    }

    if(!game_data->keys_down[RAFGL_KEY_LEFT_SHIFT])
    {
        angle_speed = 0.2f * M_PIf;
        move_speed = 2.4f;
        sensitivity = 1.0f;
    }
    else
    {
        angle_speed = 5 * 0.2f * M_PIf;
        move_speed = 5 * 2.4f;
        sensitivity = 1.0f;
    }

    int i;
    for(i = 0; i < 6; i++)
    {
        if(game_data->keys_pressed[RAFGL_KEY_1 + i])
        {
            selected_effect = i;
        }
    }


    if(game_data->is_lmb_down)
    {

        if(reshow_cursor_flag == 0)
        {
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
        }

        float ydelta = game_data->mouse_pos_y - game_data->raster_height / 2;
        float xdelta = game_data->mouse_pos_x - game_data->raster_width / 2;

        if(!last_lmb)
        {
            ydelta = 0;
            xdelta = 0;
        }

        hoffset[selected_c] -= sensitivity * ydelta / game_data->raster_height;
        camera_angle[selected_c] += sensitivity * xdelta / game_data->raster_width;

        glfwSetCursorPos(window, game_data->raster_width / 2, game_data->raster_height / 2);
        reshow_cursor_flag = 1;
    }
    else if(reshow_cursor_flag)
    {
        reshow_cursor_flag = 0;
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
    }
    last_lmb = game_data->is_lmb_down;

    aim_dir[0] = v3_norm(vec3(cosf(camera_angle[0]), hoffset[0], sinf(camera_angle[0])));
    aim_dir[1] = v3_norm(vec3(cosf(camera_angle[1]), hoffset[1], sinf(camera_angle[1])));

    if(game_data->keys_down['W']) camera_position[selected_c] = v3_add(camera_position[selected_c], v3_muls(aim_dir[selected_c], move_speed * delta_time));
    if(game_data->keys_down['S']) camera_position[selected_c] = v3_add(camera_position[selected_c], v3_muls(aim_dir[selected_c], -move_speed * delta_time));

    vec3_t right = v3_cross(aim_dir[selected_c], vec3(0.0f, 1.0f, 0.0f));
    if(game_data->keys_down['D']) camera_position[selected_c] = v3_add(camera_position[selected_c], v3_muls(right, move_speed * delta_time));
    if(game_data->keys_down['A']) camera_position[selected_c] = v3_add(camera_position[selected_c], v3_muls(right, -move_speed * delta_time));

    if(game_data->keys_pressed['R']) rotate = !rotate;


    if(game_data->keys_down[RAFGL_KEY_ESCAPE]) glfwSetWindowShouldClose(window, GLFW_TRUE);

    if(game_data->keys_down[RAFGL_KEY_SPACE]) camera_position[selected_c].y += 1.0f * delta_time * move_speed;
    if(game_data->keys_down[RAFGL_KEY_LEFT_CONTROL]) camera_position[selected_c].y -= 1.0f * delta_time * move_speed;


    float aspect = ((float)(game_data->raster_width)) / game_data->raster_height;
    projection2 = m4_perspective(fov, aspect, 0.1f, 100.0f);
    projection1 = m4_perspective(fov, 4.0f/3.0f, 0.1f, 100.0f);

    view1 = m4_look_at(camera_position[0], v3_add(camera_position[0], aim_dir[0]), camera_up[0]);
    view2 = m4_look_at(camera_position[1], v3_add(camera_position[1], aim_dir[1]), camera_up[1]);

    model1 = m4_identity();
    model2 = m4_identity();
    model1 = m4_rotation_y(model_angle);
    model1 = m4_mul(model1, m4_translation(vec3(0.0f, sinf(model_angle) * 0.45, 0.0f)));

    view_projection1 = m4_mul(projection1, view1);
    view_projection2 = m4_mul(projection2, view2);

    /* v3show(camera_position[1]); */

}


void main_state_render(GLFWwindow *window, void *args)
{

    glBindFramebuffer(GL_FRAMEBUFFER, fbo1.fbo_id);
    const GLenum buffers[] = {GL_COLOR_ATTACHMENT0, GL_COLOR_ATTACHMENT1, GL_COLOR_ATTACHMENT2};
    glDrawBuffers(3, buffers);
    glViewport(0, 0, fbo1.width, fbo1.height);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);

    glDepthMask(GL_FALSE);

    glUseProgram(skybox_shader);

    glCullFace(GL_FRONT);


    glDrawBuffers(3, buffers);
    glUniformMatrix4fv(skybox_uni_V, 1, GL_FALSE, (void*) view1.m);
    glUniformMatrix4fv(skybox_uni_P, 1, GL_FALSE, (void*) projection1.m);


    glBindVertexArray(skybox_mesh.vao_id);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);
    glBindTexture(GL_TEXTURE_CUBE_MAP, skybox_tex.tex_id);

    glDrawArrays(GL_TRIANGLES, 0, skybox_mesh.vertex_count);
    glDepthMask(GL_TRUE);

    glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(2);
    glBindVertexArray(0);


    glUseProgram(object_shader);

    glCullFace(GL_BACK);

    glDrawBuffers(3, buffers);

    glBindTexture(GL_TEXTURE_CUBE_MAP, skybox_tex.tex_id);



    glBindVertexArray(bunny_mesh.vao_id);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);

    glUniformMatrix4fv(object_uni_M, 1, GL_FALSE, (void*) model1.m);
    glUniformMatrix4fv(object_uni_VP, 1, GL_FALSE, (void*) view_projection1.m);

    glUniform3f(object_uni_object_colour, object_colour.x, object_colour.y, object_colour.z);
    glUniform3f(object_uni_light_colour, light_colour.x, light_colour.y, light_colour.z);
    glUniform3f(object_uni_light_direction, light_direction.x, light_direction.y, light_direction.z);
    glUniform3f(object_uni_ambient, ambient.x, ambient.y, ambient.z);
    glUniform3f(object_uni_camera_position, camera_position[0].x, camera_position[0].y, camera_position[0].z);

    glDrawArrays(GL_TRIANGLES, 0, bunny_mesh.vertex_count);

    /* mipmape za hajlajt */
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fbo1.tex_ids[1]);
    glGenerateMipmap(GL_TEXTURE_2D);

    glDisableVertexAttribArray(2);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(0);
    glBindVertexArray(0);


    glBindTexture(GL_TEXTURE_CUBE_MAP, 0);


    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);




    glDrawBuffers(1, buffers);
    glBindVertexArray(quad_vao);

    /* Grayscale */

    glBindFramebuffer(GL_FRAMEBUFFER, fbo_grayscaled.fbo_id);
    glViewport(0, 0, fbo_grayscaled.width, fbo_grayscaled.height);
    glUseProgram(grayscale_shader);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fbo1.tex_ids[0]);

    glDrawArrays(GL_TRIANGLES, 0, 6);



    /* horizontal blur */
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_blur_stage1.fbo_id);
    glViewport(0, 0, fbo_blur_stage1.width, fbo_blur_stage1.height);

    glUseProgram(gauss_horizontal_shader);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fbo1.tex_ids[1]);
    glUniform1f(uni_w_horizontal, fbo1.width / blur_downscale_factor);
    glUniform1f(uni_lod, BLUR_DOWNSCALE_POWER);

    glDrawArrays(GL_TRIANGLES, 0, 6);




    /* vertical blur */
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_blurred.fbo_id);
    glViewport(0, 0, fbo_blurred.width, fbo_blurred.height);

    glUseProgram(gauss_vertical_shader);

    glUniform1f(uni_h_vertical, fbo_blur_stage1.height);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fbo_blur_stage1.tex_ids[0]);

    glDrawArrays(GL_TRIANGLES, 0, 6);




    /* bloom assemble stage */
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_bloom.fbo_id);
    glViewport(0, 0, fbo_bloom.width, fbo_bloom.height);

    glUseProgram(bloom_shader);

    glUniform1i(uni_tex_slot, 0);
    glUniform1i(uni_highlight_slot, 1);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fbo1.tex_ids[0]);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, fbo_blurred.tex_ids[0]);

    glDrawArrays(GL_TRIANGLES, 0, 6);



    GLuint tmptex;

    GLuint effects[] = {fbo1.tex_ids[0], fbo1.tex_ids[2], fbo_grayscaled.tex_ids[0], fbo1.tex_ids[1], fbo_blurred.tex_ids[0], fbo_bloom.tex_ids[0]};

    tmptex = effects[selected_effect];


    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, swidth, sheight);
    glDrawBuffers(1, buffers);


    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glDepthMask(GL_FALSE);

    glUseProgram(skybox_shader);

    glCullFace(GL_FRONT);



    glUniformMatrix4fv(skybox_uni_V, 1, GL_FALSE, (void*) view2.m);
    glUniformMatrix4fv(skybox_uni_P, 1, GL_FALSE, (void*) projection2.m);


    glBindVertexArray(skybox_mesh.vao_id);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, night_tex.tex_id);

    glDrawArrays(GL_TRIANGLES, 0, skybox_mesh.vertex_count);


    glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(2);
    glBindVertexArray(0);
    glDepthMask(GL_TRUE);

    /**/

    glUseProgram(object_shader);

    glCullFace(GL_BACK);



    glBindVertexArray(mnt_mesh.vao_id);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);

    glUniformMatrix4fv(object_uni_M, 1, GL_FALSE, (void*) model2.m);
    glUniformMatrix4fv(object_uni_VP, 1, GL_FALSE, (void*) view_projection2.m);

    glUniform3f(object_uni_object_colour, 0.005f, 0.005f, 0.35f);
    glUniform3f(object_uni_light_colour, 0.5f, 0.5f, 0.5f);
    glUniform3f(object_uni_light_direction, light_direction.x, light_direction.y, light_direction.z);
    glUniform3f(object_uni_ambient, ambient.x, ambient.y, ambient.z);
    glUniform3f(object_uni_camera_position, camera_position[1].x, camera_position[1].y, camera_position[1].z);

    glDrawArrays(GL_TRIANGLES, 0, mnt_mesh.vertex_count);

    glDisableVertexAttribArray(2);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(0);
    glBindVertexArray(0);



    /**/

    glUseProgram(sc_shader);
    glUniformMatrix4fv(sc_uni_M, 1, GL_FALSE, (void*) model2.m);
    glUniformMatrix4fv(sc_uni_VP, 1, GL_FALSE, (void*) view_projection2.m);
    glBindVertexArray(sc_mesh.vao_id);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tmptex);
    glDrawArrays(GL_TRIANGLES, 0, sc_mesh.vertex_count);

    glDisableVertexAttribArray(2);
    glDisableVertexAttribArray(1);
    glDisableVertexAttribArray(0);
    glBindVertexArray(0);



}


void main_state_cleanup(GLFWwindow *window, void *args)
{

}
